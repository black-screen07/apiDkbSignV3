import json

from flask import Blueprint, request, jsonify, send_from_directory, current_app
from pathlib import Path
from app.utils.api_auth_utils import require_api_key, get_authenticated_user_by_api_key
from app.utils.public_signature_utils import (
    retrieve_certificates,
    parse_request_content,
    load_signature_image,
    load_pdf,
    update_signature_volumes,
    get_user_company,
    validate_signature_volumes,
    validate_signature_params,
    process_document_consent,
    create_pdf_signer,
    apply_optional_texts,
    apply_stamp,
    prepare_pdf_paths,
    apply_qr_codes,
    sign_pdf_pages,
    save_final_pdf,
    update_document_record
)
from app.models import db, Document, Contact, Signer
from datetime import datetime
import uuid
import os
from PIL import Image

publicapi_signature_bp = Blueprint('publicapi_signature_bp', __name__)

SIGNED_PDF_FOLDER = Path("documents/doc_signed")
SIGNED_PDF_FOLDER.mkdir(parents=True, exist_ok=True)
COMPANY_SIGNATURE_FOLDER = Path("signatures/companies")

@publicapi_signature_bp.route('/documents/doc_signed/<path:subfolder>/<filename>', methods=['GET'])
def download_file(subfolder, filename):
    """
    Endpoint pour télécharger un fichier signé en fonction du sous-dossier.
    """
    file_path = SIGNED_PDF_FOLDER / subfolder / filename

    if not file_path.exists():
        return jsonify({"error": "Fichier introuvable."}), 404

    return send_from_directory((SIGNED_PDF_FOLDER / subfolder).resolve(), filename)

@publicapi_signature_bp.route('/sign-pdf', methods=['POST'])
@require_api_key
def sign_pdf():
    """
    Point d'entrée pour la signature d'un PDF.
    Authentification par API key requise.
    """
    try:
        # 1. Récupération et validation de l'utilisateur et de son entreprise
        user = get_authenticated_user_by_api_key()
        company = get_user_company(user)
        validate_signature_volumes(user, company)

        # 2. Récupération des certificats et du cachet du signataire
        cert_path, key_path, cert_chain = retrieve_certificates(user, company)
        if not cert_path or not key_path:
            return jsonify({"error": "Certificat ou clé privée introuvable."}), 400
        signer_stamp = load_signature_image(user)

        # 3. Analyse et validation de la requête
        params, file_url, file = parse_request_content(request)
        validate_signature_params(params)

        # 4. Gestion du consentement et récupération du document le cas échéant
        document = process_document_consent(user, company, params)

        # 5. Préparation du signataire PDF
        signer = create_pdf_signer(key_path, cert_path, cert_chain)

        # 6. Chargement du PDF et application des modifications avant signature
        input_pdf_buffer = load_pdf(file, file_url)
        input_pdf_buffer = apply_optional_texts(input_pdf_buffer, params)
        input_pdf_buffer = apply_stamp(input_pdf_buffer, user, params)

        # 7. Préparation de l'emplacement de sauvegarde et de l'URL finale
        full_signed_pdf_url, relative_file_path, signed_pdf_path = prepare_pdf_paths(user, company)

        # 8. Application des QR codes (mise à jour des données si nécessaire)
        input_pdf_buffer = apply_qr_codes(input_pdf_buffer, params, user, full_signed_pdf_url)

        # 9. Application des signatures sur chaque page concernée avec informations de l'utilisateur
        user_info = {
            'name': user.name if hasattr(user, 'name') and user.name else user.email,
            'sub_name': user.sub_name if hasattr(user, 'sub_name') else '',
            'function': 'Utilisateur authentifié'
        }
        input_pdf_buffer = sign_pdf_pages(input_pdf_buffer, params["pages"], signer, signer_stamp, user_info)

        # 10. Enregistrement du PDF final sur le disque
        save_final_pdf(input_pdf_buffer, signed_pdf_path)

        # 11. Mise à jour de la base de données
        update_document_record(user, params, document, relative_file_path)
        update_signature_volumes(user, company, 1)
        db.session.commit()

        return jsonify({
            "message": "Document signé avec succès.",
            "doc_signed": full_signed_pdf_url
        }), 200

    except Exception as e:
        current_app.logger.error(f"Erreur lors de la signature : {str(e)}")
        return jsonify({"error": f"Erreur lors de la signature : {str(e)}"}), 500

@publicapi_signature_bp.route('/sign-pdfs', methods=['POST'])
@require_api_key
def sign_multiple_pdfs():
    """
    Point d'entrée pour la signature de plusieurs PDFs via JSON.
    """
    try:
        # 1. Récupération et validation de l'utilisateur et de son entreprise
        user = get_authenticated_user_by_api_key()
        company = get_user_company(user)
        validate_signature_volumes(user, company)

        # 2. Récupération des certificats et du cachet du signataire
        cert_path, key_path, cert_chain = retrieve_certificates(user, company)
        if not cert_path or not key_path:
            return jsonify({"error": "Certificat ou clé privée introuvable."}), 400
        signer_stamp = load_signature_image(user)

        # 3. Vérification du corps JSON
        data = request.get_json()
        if not data or 'documents' not in data or not data['documents']:
            return jsonify({"error": "Aucun document fourni."}), 400

        signed_results = []
        total_signatures = 0

        # 4. Traiter chaque document
        for doc in data['documents']:
            file_url = doc.get('file_url')
            params = doc.get('params')
            if not file_url or not params:
                return jsonify({"error": "file_url ou params manquants pour un document."}), 400

            # 5. Validation des paramètres
            validate_signature_params(params)

            # 6. Gestion du consentement et récupération du document
            document = process_document_consent(user, company, params)

            # 7. Préparation du signataire PDF
            signer = create_pdf_signer(key_path, cert_path, cert_chain)

            # 8. Chargement du PDF
            input_pdf_buffer = load_pdf(None, file_url)  # Aucun fichier uploadé, seulement file_url

            # 9. Application des modifications avant signature
            input_pdf_buffer = apply_optional_texts(input_pdf_buffer, params)
            input_pdf_buffer = apply_stamp(input_pdf_buffer, user, params)

            # 10. Préparation des chemins de sauvegarde
            full_signed_pdf_url, relative_file_path, signed_pdf_path = prepare_pdf_paths(user, company)

            # 11. Application des QR codes
            input_pdf_buffer = apply_qr_codes(input_pdf_buffer, params, user, full_signed_pdf_url)

            # 12. Application des signatures avec informations de l'utilisateur
            user_info = {
                'name': user.name if hasattr(user, 'name') and user.name else user.email,
                'sub_name': user.sub_name if hasattr(user, 'sub_name') else '',
                'function': 'Utilisateur authentifié'
            }
            input_pdf_buffer = sign_pdf_pages(input_pdf_buffer, params.get("pages", []), signer, signer_stamp, user_info)

            # 13. Enregistrement du PDF final
            save_final_pdf(input_pdf_buffer, signed_pdf_path)

            # 14. Mise à jour de la base de données
            update_document_record(user, params, document, relative_file_path)
            total_signatures += 1

            signed_results.append({
                "filename": params.get("name", "Unnamed"),
                "message": "Document signé avec succès.",
                "doc_signed": full_signed_pdf_url
            })

        # 15. Mise à jour du volume de signatures
        update_signature_volumes(user, company, total_signatures)
        db.session.commit()

        return jsonify({
            "message": f"{len(signed_results)} document(s) signé(s) avec succès.",
            "signed_documents": signed_results
        }), 200

    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Erreur lors de la signature : {str(e)}")
        return jsonify({"error": f"Erreur lors de la signature : {str(e)}"}), 500


@publicapi_signature_bp.route('/sign-upload-multiple', methods=['POST'])
@require_api_key
def sign_upload_multiple_documents():
    """
    Point d'entrée pour la signature de plusieurs PDFs uploadés avec signataires externes.
    
    Paramètres attendus :
    - documents[] : fichiers PDF à signer
    - signers_data : JSON avec les informations des signataires externes
    - signature_params : JSON avec les paramètres de signature pour chaque document
    
    Format signers_data :
    [
        {
            "name": "Nom du signataire",
            "firstname": "Prénom", 
            "function": "Fonction",
            "signature_image": "nom_fichier_signature.png"
        }
    ]
    
    Format signature_params :
    [
        {
            "document_index": 0,
            "signer_index": 0,
            "pages": [{"page": 0, "signatures": [{"x": 100, "y": 200}]}],
            "stamp_pages": [0],
            "qrcodes": [{"page": 0, "x": 50, "y": 50, "data": "custom_data"}]
        }
    ]
    """
    try:
        # 1. Récupération et validation de l'utilisateur et de son entreprise
        user = get_authenticated_user_by_api_key()
        company = get_user_company(user)
        validate_signature_volumes(user, company)

        # 2. Récupération des certificats de l'utilisateur initiateur
        cert_path, key_path, cert_chain = retrieve_certificates(user, company)
        if not cert_path or not key_path:
            return jsonify({"error": "Certificat ou clé privée introuvable."}), 400

        # 3. Vérification des fichiers uploadés
        uploaded_files = request.files.getlist('documents')
        
        if not uploaded_files:
            return jsonify({"error": "Aucun document fourni."}), 400
        
        # Limite de sécurité pour éviter les problèmes de performance
        MAX_DOCUMENTS_PER_REQUEST = 100
        if len(uploaded_files) > MAX_DOCUMENTS_PER_REQUEST:
            return jsonify({
                "error": f"Nombre maximum de documents dépassé. Limite: {MAX_DOCUMENTS_PER_REQUEST} documents par requête."
            }), 400

        # 4. Récupération des données des signataires externes
        signers_data_json = request.form.get('signers_data')
        if not signers_data_json:
            return jsonify({"error": "Données des signataires manquantes."}), 400
        
        try:
            signers_data = json.loads(signers_data_json)
        except json.JSONDecodeError:
            return jsonify({"error": "Format JSON invalide pour signers_data."}), 400

        # 5. Récupération des paramètres de signature
        signature_params_json = request.form.get('signature_params')
        if not signature_params_json:
            return jsonify({"error": "Paramètres de signature manquants."}), 400
        
        try:
            signature_params = json.loads(signature_params_json)
        except json.JSONDecodeError:
            return jsonify({"error": "Format JSON invalide pour signature_params."}), 400

        # 6. Récupération des images de signature pour chaque signataire
        signature_images = {}
        for i, signer in enumerate(signers_data):
            image_key = f'signature_image_{i}'
            if image_key in request.files:
                signature_images[i] = request.files[image_key]
        
        for i, signer in enumerate(signers_data):
            if 'signature_image' in signer:
                # Rechercher par nom de fichier
                for key, file in request.files.items():
                    if key.startswith('signature_image_') and file.filename == signer['signature_image']:
                        signature_images[i] = file
                        current_app.logger.info(f"DEBUG - Image trouvée pour signataire {i}: {file.filename}")
                        break

        # 7. Validation des signataires
        for i, signer in enumerate(signers_data):
            required_fields = ['name', 'firstname', 'function']
            for field in required_fields:
                if not signer.get(field):
                    return jsonify({"error": f"Champ '{field}' manquant pour le signataire {i}."}), 400

        # 8. Traitement de chaque document
        signed_results = []
        total_signatures = 0

        for doc_index, uploaded_file in enumerate(uploaded_files):
            if not uploaded_file or uploaded_file.filename == '':
                continue

            # 9. Filtrer les paramètres de signature pour ce document
            doc_signature_params = [p for p in signature_params if p.get('document_index') == doc_index]
            if not doc_signature_params:
                return jsonify({"error": f"Aucun paramètre de signature trouvé pour le document {doc_index}."}), 400

            # 10. Chargement du PDF uploadé
            input_pdf_buffer = load_pdf(uploaded_file, None)
            if not input_pdf_buffer:
                return jsonify({"error": f"Impossible de charger le document {doc_index}."}), 400

            # 11. Préparation des chemins de sauvegarde
            full_signed_pdf_url, relative_file_path, signed_pdf_path = prepare_pdf_paths(user, company)

            # 12. Application des signatures pour chaque signataire sur ce document
            current_pdf_buffer = input_pdf_buffer
            
            for param in doc_signature_params:
                signer_index = param.get('signer_index')
                if signer_index is None or signer_index >= len(signers_data):
                    return jsonify({"error": f"Index de signataire invalide : {signer_index}."}), 400

                signer_info = signers_data[signer_index]
                pages = param.get('pages', [])
                
                if not pages:
                    continue

                # 13. Chargement de l'image de signature du signataire externe
                signer_stamp = None
                if signer_index in signature_images:
                    if f'signature_image_{signer_index}' in request.files:
                        sig_image_file = request.files[f'signature_image_{signer_index}']
                        if sig_image_file and sig_image_file.filename:
                            try:
                                # TEST: Utiliser l'image originale sans modification
                                sig_image_pil = Image.open(sig_image_file.stream)
                                signer_stamp = sig_image_pil
                                
                                current_app.logger.info(f"Image de signature originale pour signataire {signer_index}: {sig_image_pil.size}, mode: {sig_image_pil.mode}")
                            except Exception as e:
                                current_app.logger.error(f"Erreur lors du chargement de l'image de signature pour le signataire {signer_index}: {str(e)}")
                
                # Si aucune image spécifique n'est fournie, utiliser l'image par défaut de l'utilisateur
                if signer_stamp is None:
                    try:
                        signer_stamp = load_signature_image(user)
                        current_app.logger.info(f"Utilisation de l'image de signature par défaut de l'utilisateur")
                    except Exception as e:
                        current_app.logger.error(f"Impossible de charger l'image de signature par défaut: {str(e)}")
                        continue  # Passer ce signataire si aucune image n'est disponible

                # 14. Configuration du signataire PyHanko (utilise le certificat de l'initiateur)
                signer = create_pdf_signer(key_path, cert_path, cert_chain)

                # 15. Application des signatures sur les pages avec informations du signataire
                signer_info = None
                if signer_index is not None and signer_index < len(signers_data):
                    signer_data = signers_data[signer_index]
                    signer_info = {
                        'name': signer_data.get('name', ''),
                        'sub_name': signer_data.get('firstname', ''),  # Utiliser firstname du JSON
                        'function': signer_data.get('function', ''),
                        'email': signer_data.get('email', ''),
                        'phone': signer_data.get('phone', '')
                    }
                
                current_pdf_buffer = sign_pdf_pages(current_pdf_buffer, pages, signer, signer_stamp, signer_info)

                # 16. Application des QR codes si spécifiés
                qrcodes = param.get('qrcodes', [])
                if qrcodes:
                    current_pdf_buffer = apply_qr_codes(current_pdf_buffer, {'qrcodes': qrcodes}, user, full_signed_pdf_url)

                # 17. Application du cachet si spécifié
                stamp_pages = param.get('stamp_pages', [])
                if stamp_pages:
                    current_pdf_buffer = apply_stamp(current_pdf_buffer, user, {'stamp_pages': stamp_pages})

                # Note: signer_stamp est maintenant un objet PIL Image, pas un fichier

            # 18. Sauvegarde du PDF final
            save_final_pdf(current_pdf_buffer, signed_pdf_path)

            # 19. Création d'un enregistrement de document en base
            try:
                document_name = uploaded_file.filename or f"document_{doc_index}.pdf"
                new_document = Document(
                    name=document_name,
                    file_path=relative_file_path,
                    user_id=user.id,
                    status="signed",
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow()
                )
                db.session.add(new_document)
                db.session.commit()

                # 20. Création des enregistrements de signataires externes
                for param in doc_signature_params:
                    signer_index = param.get('signer_index')
                    if signer_index is not None and signer_index < len(signers_data):
                        signer_info = signers_data[signer_index]
                        
                        # Construire le nom complet du contact
                        full_contact_name = signer_info['name']
                        if signer_info.get('firstname'):
                            full_contact_name += f" {signer_info['firstname']}"
                        
                        # Gérer l'email du signataire
                        signer_email = signer_info.get('email')
                        external_contact = None
                        
                        if signer_email:
                            # Vérifier si un contact avec cet email existe déjà pour cet utilisateur
                            external_contact = Contact.query.filter_by(
                                user_id=user.id,
                                email=signer_email
                            ).first()
                        
                        if not external_contact:
                            # Créer un nouveau contact si aucun n'existe ou si pas d'email fourni
                            contact_email = signer_email or f"external_{uuid.uuid4().hex}@temp.com"
                            external_contact = Contact(
                                name=full_contact_name,
                                email=contact_email,
                                phone=signer_info.get('phone', ''),
                                user_id=user.id,
                                created_at=datetime.utcnow()
                            )
                            db.session.add(external_contact)
                            db.session.flush()  # Pour obtenir l'ID
                        else:
                            # Mettre à jour les informations du contact existant si nécessaire
                            if signer_info.get('phone') and not external_contact.phone:
                                external_contact.phone = signer_info.get('phone')
                            external_contact.updated_at = datetime.utcnow()

                        # Créer l'enregistrement de signataire
                        signer_record = Signer(
                            document_id=new_document.id,
                            signer_id=external_contact.id,
                            account_type="external",
                            status="signed",
                            priority=signer_index + 1,
                            uuid=str(uuid.uuid4()),
                            created_at=datetime.utcnow(),
                            signed_at=datetime.utcnow()
                        )
                        db.session.add(signer_record)

                db.session.commit()

            except Exception as e:
                current_app.logger.error(f"Erreur lors de la création du document en base : {str(e)}")
                # Continue même si l'enregistrement en base échoue

            signed_results.append({
                "document_name": uploaded_file.filename,
                "signed_pdf_url": full_signed_pdf_url,
                "signers": [{
                    "name": signer['name'],
                    "firstname": signer['firstname'], 
                    "function": signer['function']
                } for signer in signers_data]
            })
            
            # Compter 1 signature par document traité
            total_signatures += 1

        # 21. Mise à jour des volumes de signature
        current_app.logger.info(f"Décompte de {total_signatures} document(s) signé(s) pour l'utilisateur {user.email}")
        update_signature_volumes(user, company, total_signatures)
        db.session.commit()

        return jsonify({
            "message": f"{len(signed_results)} document(s) signé(s) avec succès avec signataires externes.",
            "signed_documents": signed_results,
            "total_signatures": total_signatures
        }), 200

    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Erreur lors de la signature avec upload multiple : {str(e)}")
        return jsonify({"error": f"Erreur lors de la signature : {str(e)}"}), 500

